export { default } from "./RaiseComplaint";
