export { default } from "./ComplaintDetails";
