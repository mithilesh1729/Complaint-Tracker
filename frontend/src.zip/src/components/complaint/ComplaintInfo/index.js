export { default } from "./ComplaintInfo";
