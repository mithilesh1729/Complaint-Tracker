export { default } from "./ComplaintCard";
