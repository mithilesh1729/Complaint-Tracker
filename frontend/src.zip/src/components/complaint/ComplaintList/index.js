export { default } from "./ComplaintList";
