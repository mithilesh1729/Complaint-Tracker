export { default } from "./ComplaintHeader";
