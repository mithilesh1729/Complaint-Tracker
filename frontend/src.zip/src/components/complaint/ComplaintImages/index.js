export { default } from "./ComplaintImages";
