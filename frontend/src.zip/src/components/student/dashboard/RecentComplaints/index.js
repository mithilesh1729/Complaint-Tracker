export { default } from "./RecentComplaints";
