export { default } from "./WelcomeCard";
