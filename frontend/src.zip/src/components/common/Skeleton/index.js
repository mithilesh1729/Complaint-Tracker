export { default } from "./Skeleton";
