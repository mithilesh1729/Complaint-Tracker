import { useState } from "react";

import { resolveComplaint } from "../services/officeService";

function useOfficeComplaintActions(refresh) {
  const [loading, setLoading] = useState(false);

  async function resolve(complaintId, payload = {}) {
    try {
      setLoading(true);

      await resolveComplaint(complaintId, payload);

      if (refresh) {
        await refresh();
      }

      return {
        success: true,
      };
    } catch (error) {
      console.error(error);

      return {
        success: false,
      };
    } finally {
      setLoading(false);
    }
  }

  return {
    loading,
    resolveComplaint: resolve,
  };
}

export default useOfficeComplaintActions;
