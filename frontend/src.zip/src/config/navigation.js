import {
  FaHome,
  FaPlusCircle,
  FaClipboardList,
  FaUser,
  FaTasks,
  FaUsers,
  FaBuilding,
  FaChartBar,
} from "react-icons/fa";

import { ROUTES } from "../constants/routes";
import { ROLES } from "../constants/roles";

export const NAVIGATION = {
  [ROLES.STUDENT]: [
    {
      label: "Dashboard",
      path: ROUTES.STUDENT_DASHBOARD,
      icon: FaHome,
    },
    {
      label: "Raise Complaint",
      path: ROUTES.CREATE_COMPLAINT,
      icon: FaPlusCircle,
    },
    {
      label: "My Complaints",
      path: ROUTES.MY_COMPLAINTS,
      icon: FaClipboardList,
    },
    {
      label: "Profile",
      path: ROUTES.STUDENT_PROFILE,
      icon: FaUser,
    },
  ],

  [ROLES.HOSTEL_OFFICE]: [
    {
      label: "Dashboard",
      path: ROUTES.OFFICE_DASHBOARD,
      icon: FaHome,
    },
    {
      label: "Incoming Complaints",
      path: ROUTES.OFFICE_QUEUE,
      icon: FaClipboardList,
    },
    {
      label: "My Assigned Work",
      path: ROUTES.OFFICE_ASSIGNED,
      icon: FaTasks,
    },
    {
      label: "Profile",
      path: ROUTES.OFFICE_PROFILE,
      icon: FaUser,
    },
  ],

  [ROLES.ADMIN]: [
    {
      label: "Students",
      path: ROUTES.ADMIN_STUDENTS,
      icon: FaUsers,
    },
    {
      label: "Staff",
      path: ROUTES.ADMIN_STAFF,
      icon: FaUsers,
    },
    {
      label: "Hostels",
      path: ROUTES.ADMIN_HOSTELS,
      icon: FaBuilding,
    },
    {
      label: "Analytics",
      path: ROUTES.ADMIN_ANALYTICS,
      icon: FaChartBar,
    },
  ],
};
